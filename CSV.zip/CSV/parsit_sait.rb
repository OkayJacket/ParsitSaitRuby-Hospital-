require 'nokogiri'
require 'httparty'
require 'csv'

def parse_target_li_elements(url, csv_filename)
  response = HTTParty.get(url)

  if response.success?
    doc = Nokogiri::HTML(response.body)

    target_elements = doc.css('div#BlinkDBContent_849210 > ul > li')

    if target_elements.any?
      CSV.open(csv_filename, 'w') do |csv|
        target_elements.each do |element|
          csv << [element.text.strip]
        end
      end

      puts "Data about hospital elements have been successfully written to #{csv_filename}."
    else
      puts 'No target elements found on the page.'
    end
  else
    puts "Failed to retrieve the page. Status code: #{response.code}"
  end
end

website_url = 'https://www.hospitalsafetygrade.org/all-hospitals'
csv_filename = 'hospital_elements.csv'

parse_target_li_elements(website_url, csv_filename)